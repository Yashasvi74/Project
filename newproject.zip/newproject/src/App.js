import logo from './logo.svg';
import './App.css';
import Navbar from './Component/NavBar';
import Home from './Component/Home';
import Skills from './Component/Skills';
import { BrowserRouter,Routes, Route } from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="Skills" element={<Home/>}></Route>

      </Routes>
      </BrowserRouter>
      <Home/>
    </div>
  );
}

export default App;

