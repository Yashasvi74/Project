import React from 'react'

function Footer() {
  return (
    <div>
        this is a Footer Component
    </div>
  )
}

export default Footer