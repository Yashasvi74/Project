import React from 'react'
import Navbar from './NavBar'
import Footer from './Footer'

function Home() {
  return (
    <div>
        <Navbar/>
        <h1>Render HTML,CSS AND JSX FILES HERE</h1>
        <Footer/>
    </div>
  )
}

export default Home