import React from 'react'
import './Skills.css'

function Skills() {
  return (
    <div>
        <ol>
            <li>HTML
            </li>
            <li>CSS</li>
            <li>java</li>
        </ol>

    </div>
  )
}

export default Skills