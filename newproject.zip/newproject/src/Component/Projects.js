import React ,{Component}from 'react'

export default class ChangeTextCaseWithTheme extends Component {
    constructor(){
        super();
        this.state={
            text:' ',
            theme:'light'
        };
        this.handleChnage=this.handleChnage.bind()
    }
  return (
    <div>Projects</div>
  )
}

export default Projects